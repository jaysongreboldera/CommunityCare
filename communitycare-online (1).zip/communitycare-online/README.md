# CommunityCare Online — multi-user starter

This is a deployable **starter**, not a certified production-ready system for sensitive personal information.

## Setup
1. Create a Supabase project at https://supabase.com and open SQL Editor.
2. Run the entire `schema.sql` file.
3. Under Authentication > Providers / Settings, disable public signups unless you have an approved invitation workflow. Configure appropriate MFA and password policies.
4. Create an admin user in Authentication > Users. Copy their UUID.
5. Run `insert into public.communities(name,type) values ('Example Community','barangay') returning id;` and copy the returned community UUID.
6. Run `insert into public.memberships(user_id,community_id,role) values ('ADMIN_USER_UUID','COMMUNITY_UUID','admin');` replacing both UUIDs.
7. Host `index.html` on HTTPS (Netlify, Vercel, etc.) and enter your Supabase **project URL** and **public anon/publishable key**. **Never** put your Supabase service-role key in HTML.
8. To add caseworkers/viewers, create their users in Supabase Auth and insert memberships with `caseworker` or `viewer` role. For more communities, create another community and assign memberships.

## Implemented
- Password sign-in via Supabase Auth
- Multi-community membership and role-specific access enforced with Postgres RLS
- Household registry, optional religious affiliation with consent confirmation
- Family-member profiles and separate medical support records
- Assistance history, due and overdue follow-up dashboard (when app is opened)
- Admin/caseworker writes, viewer read-only; viewer cannot read medical notes
- Cross-community foreign-key consistency checks

## Important limitations before real deployment
- **No automated email/SMS reminders yet**: the dashboard displays due dates; scheduled jobs and notification consent are required for background reminders.
- No admin staff-management UI: initial users and memberships are provisioned through Supabase dashboard/SQL.
- No edit/delete UI, audit log, formal consent records, data export, retention automation, or backup/restore workflow yet.
- The first 1,000 records per table are loaded; implement pagination for larger communities.
- Medical records are restricted to admin/caseworker roles within the community; finer-grained clinical access controls, audited access, and encryption/key management may be necessary.
- Religion and medical information are sensitive personal data. Establish a lawful basis, notices, retention policies, DPIA where appropriate, staff training, incident response, and compliance with applicable law (including the Philippine Data Privacy Act when relevant) before collecting real data.
- Avoid putting real patient or resident data into demo projects. Test with fictional data.
- Review SQL security policies with a qualified security engineer before live use.

## Multiple community projects / locations (new)

For an existing installation, run `project-upgrade.sql` in Supabase SQL Editor after `schema.sql`. This preserves your current data. Then authorize the account allowed to create projects using the final commented `insert into public.project_creators` command in that file, replacing `YOUR_AUTH_USER_UUID` with the real UUID from Supabase Authentication > Users. **Do not give every staff member this permission.**

After signing in as an authorized project creator, choose **+ New community project**. Enter its name, type, location, and optional description. The new project is created with its own community ID, and your account becomes its administrator. Use the **Active community** dropdown to switch projects; each dashboard and all records are scoped to the selected project. Existing communities without a location still work; you can fill in their location using the Supabase dashboard.

This creates logical projects in one Supabase database, not separate Supabase infrastructure. Access is still restricted through community memberships and RLS. Users only see projects where they have membership. Before entering real medical, religious, or financial data, commission a security and privacy review, configure appropriate retention and consent processes, and test access boundaries across roles and communities. No automated email/SMS delivery is implemented.
