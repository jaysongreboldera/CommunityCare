-- Run in Supabase SQL Editor. Create the first admin via Authentication > Users,
-- then insert their membership with SQL after creating a community.
create extension if not exists pgcrypto;
create table public.communities (id uuid primary key default gen_random_uuid(), name text not null, type text not null default 'other', created_at timestamptz default now());
create table public.memberships (user_id uuid not null references auth.users(id) on delete cascade, community_id uuid not null references public.communities(id) on delete cascade, role text not null check(role in ('admin','caseworker','viewer')), primary key(user_id,community_id));
create function public.member_role(cid uuid) returns text language sql stable security definer set search_path=public as $$ select role from public.memberships where user_id=auth.uid() and community_id=cid limit 1 $$;
create function public.has_role(cid uuid, roles text[]) returns boolean language sql stable security definer set search_path=public as $$ select coalesce(public.member_role(cid)=any(roles),false) $$;
create table public.households (id uuid primary key default gen_random_uuid(), community_id uuid not null references public.communities(id), family_code text not null, head_name text not null, phone text, address text, income_band text, housing text, religion text, religion_consent boolean not null default false, needs text, priority text not null default 'monitor' check(priority in ('urgent','support','monitor','stable')), created_at timestamptz default now(), unique(community_id,family_code));
create table public.members (id uuid primary key default gen_random_uuid(), community_id uuid not null references public.communities(id), household_id uuid not null references public.households(id) on delete cascade, full_name text not null, relationship text, birth_date date, employment text, education text, created_at timestamptz default now());
create table public.medical_records (id uuid primary key default gen_random_uuid(), community_id uuid not null references public.communities(id), member_id uuid not null references public.members(id) on delete cascade, details text not null, care_needs text, consent_confirmed boolean not null default false, created_at timestamptz default now());
create table public.assistance (id uuid primary key default gen_random_uuid(), community_id uuid not null references public.communities(id), household_id uuid not null references public.households(id) on delete cascade, assistance_type text not null, description text, status text not null default 'open' check(status in ('open','in_progress','resolved')), assigned_to text, follow_up_date date, created_at timestamptz default now());
create index on public.households(community_id); create index on public.members(community_id,household_id); create index on public.medical_records(community_id,member_id); create index on public.assistance(community_id,follow_up_date);
-- Prevent cross-community references even if a client submits forged IDs.
create function public.validate_household_community() returns trigger language plpgsql as $$ begin if not exists(select 1 from public.households h where h.id=new.household_id and h.community_id=new.community_id) then raise exception 'Household/community mismatch'; end if; return new; end $$;
create trigger member_household_guard before insert or update on public.members for each row execute function public.validate_household_community();
create trigger assistance_household_guard before insert or update on public.assistance for each row execute function public.validate_household_community();
create function public.validate_member_community() returns trigger language plpgsql as $$ begin if not exists(select 1 from public.members m where m.id=new.member_id and m.community_id=new.community_id) then raise exception 'Member/community mismatch'; end if; return new; end $$;
create trigger medical_member_guard before insert or update on public.medical_records for each row execute function public.validate_member_community();
alter table public.communities enable row level security;
alter table public.memberships enable row level security;
alter table public.households enable row level security;
alter table public.members enable row level security;
alter table public.medical_records enable row level security;
alter table public.assistance enable row level security;
create policy community_read on public.communities for select to authenticated using(public.has_role(id,array['admin','caseworker','viewer']));
create policy memberships_read on public.memberships for select to authenticated using(user_id=auth.uid() or public.has_role(community_id,array['admin']));
create policy memberships_admin_insert on public.memberships for insert to authenticated with check(public.has_role(community_id,array['admin']));
create policy memberships_admin_update on public.memberships for update to authenticated using(public.has_role(community_id,array['admin'])) with check(public.has_role(community_id,array['admin']));
create policy memberships_admin_delete on public.memberships for delete to authenticated using(public.has_role(community_id,array['admin']));
create policy household_read on public.households for select to authenticated using(public.has_role(community_id,array['admin','caseworker','viewer']));
create policy household_write on public.households for insert to authenticated with check(public.has_role(community_id,array['admin','caseworker']) and (religion is null or religion_consent));
create policy household_update on public.households for update to authenticated using(public.has_role(community_id,array['admin','caseworker'])) with check(public.has_role(community_id,array['admin','caseworker']) and (religion is null or religion_consent));
create policy household_delete on public.households for delete to authenticated using(public.has_role(community_id,array['admin']));
create policy members_read on public.members for select to authenticated using(public.has_role(community_id,array['admin','caseworker','viewer']));
create policy members_insert on public.members for insert to authenticated with check(public.has_role(community_id,array['admin','caseworker']));
create policy members_update on public.members for update to authenticated using(public.has_role(community_id,array['admin','caseworker'])) with check(public.has_role(community_id,array['admin','caseworker']));
create policy members_delete on public.members for delete to authenticated using(public.has_role(community_id,array['admin']));
create policy medical_read on public.medical_records for select to authenticated using(public.has_role(community_id,array['admin','caseworker']));
create policy medical_insert on public.medical_records for insert to authenticated with check(public.has_role(community_id,array['admin','caseworker']) and consent_confirmed);
create policy medical_update on public.medical_records for update to authenticated using(public.has_role(community_id,array['admin','caseworker'])) with check(public.has_role(community_id,array['admin','caseworker']) and consent_confirmed);
create policy medical_delete on public.medical_records for delete to authenticated using(public.has_role(community_id,array['admin']));
create policy assistance_read on public.assistance for select to authenticated using(public.has_role(community_id,array['admin','caseworker','viewer']));
create policy assistance_insert on public.assistance for insert to authenticated with check(public.has_role(community_id,array['admin','caseworker']));
create policy assistance_update on public.assistance for update to authenticated using(public.has_role(community_id,array['admin','caseworker'])) with check(public.has_role(community_id,array['admin','caseworker']));
create policy assistance_delete on public.assistance for delete to authenticated using(public.has_role(community_id,array['admin']));
-- Admin onboarding: create the auth user in Supabase dashboard first, then run:
-- insert into public.communities(name,type) values ('My Community','barangay') returning id;
-- insert into public.memberships(user_id,community_id,role) values ('AUTH_USER_UUID','COMMUNITY_UUID','admin');
-- For staff, create/invite their auth user in Supabase, then insert membership as admin in SQL.
