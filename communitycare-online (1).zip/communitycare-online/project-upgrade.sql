-- Run once in Supabase SQL Editor AFTER the original schema.sql.
-- Existing records and projects are retained.
alter table public.communities add column if not exists location text;
alter table public.communities add column if not exists description text;
-- Explicit platform permission; regular community admins cannot create arbitrary projects.
create table if not exists public.project_creators (
 user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.project_creators enable row level security;
revoke all on public.project_creators from anon, authenticated;
-- This is only a permission check, not an invitation to expose the creator list.
create or replace function public.can_create_community_project()
returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from public.project_creators where user_id = auth.uid());
$$;
revoke all on function public.can_create_community_project() from public;
grant execute on function public.can_create_community_project() to authenticated;
-- Atomic project creation + admin membership; user ID is ALWAYS derived from auth.uid().
create or replace function public.create_community_project(
 p_name text, p_type text, p_location text, p_description text default null
) returns uuid language plpgsql security definer set search_path = '' as $$
declare new_id uuid;
begin
 if auth.uid() is null or not public.can_create_community_project() then
   raise exception 'Not authorized to create community projects';
 end if;
 if length(trim(coalesce(p_name,''))) < 2 or length(p_name)>120 then
   raise exception 'Project name must be between 2 and 120 characters';
 end if;
 if p_type not in ('barangay','church','ngo','residential','other') then
   raise exception 'Invalid community type';
 end if;
 if length(trim(coalesce(p_location,''))) < 2 or length(p_location)>250 then
   raise exception 'Location is required (2-250 characters)';
 end if;
 if length(coalesce(p_description,''))>1000 then
   raise exception 'Description is too long';
 end if;
 insert into public.communities(name,type,location,description)
 values(trim(p_name),p_type,trim(p_location),nullif(trim(p_description),'')) returning id into new_id;
 insert into public.memberships(user_id,community_id,role) values(auth.uid(),new_id,'admin');
 return new_id;
end;
$$;
revoke all on function public.create_community_project(text,text,text,text) from public;
grant execute on function public.create_community_project(text,text,text,text) to authenticated;
-- To authorize your first project creator, replace the UUID with your Supabase Auth user UUID:
-- insert into public.project_creators(user_id) values ('YOUR_AUTH_USER_UUID') on conflict do nothing;
